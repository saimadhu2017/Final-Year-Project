**Y17 Project Batch-304**



**REAL TIME SENTIMENT ANALYSIS ON TWITTER**


Real-time analysis is one of the vital things where it is used widely in Big data analytics. Here In
our project, we are developing a cluster or group which is a set of tweets that are created by
different users on the Twitter website to tell the user on how he is behaving which is mainly
focusing on sentimental analysis. Here we used Flume to collect the real-time data which actually
integrate with the Twitter (website) developer account. To ensure regarding how the data is
secured, real-time and fast information processing, we used the most famous or popular tools that
are being used like Flume, Hive and ML algorithms in python to get the results more accurately.
We used k means clustering technique but before using that we have used TF-IDF approach which
gives the result in the table format which contains the values of each tweet or sentence that are
being tweeted by a user. Here, the values that we got in TF-IDF tells how a sentence is positive or
negative or neutral. Now, K means approach comes because we have converted each sentence with
a specific value which tells positive or negative or neutral. So, based on the values which are very
near to each other, they will form a single group or a cluster. So, in our project, we obviously we
have only 3 clusters, either positive or negative or neutral. Finally, we have to get the output which
tells the user that whatever he or her tweets are either positive or negative or neutral.

**Outcome of the Project:**

By the end of the project we will collect the real time twitter data to show how flume,hive and python ML algorthims are far better than the traditional methods by conducting experimental simulations and Doing analysis for predicting the user behavior pattern using various Machine learning algorithms on the website.